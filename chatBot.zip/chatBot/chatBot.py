import cohere
import tkinter as tk
from tkinter import scrolledtext

cohere.api_key = "THKmxxEXAxLvjHHcmr6cdPAg2M1grInAIfQOGy3v"
co = cohere.Client(cohere.api_key)

def chat_with_gpts(prompt):
    try:
        response = co.generate(
            prompt=prompt,
            max_tokens=150,
            temperature=0.7,
        )
        return response.generations[0].text.strip()
    except Exception as e:
        return f"Error: {e}"

def on_send():
    user_input = user_entry.get()
    if user_input.lower() in ["quit", "exit", "bye"]:
        window.quit()
    else:
        chat_box.config(state=tk.NORMAL)
        chat_box.insert(tk.END, f"You: {user_input}\n", 'user')
        response = chat_with_gpts(user_input)
        chat_box.insert(tk.END, f"\n\nChatbot: {response}\n\n\n", 'chatbot')
        chat_box.yview(tk.END)
        user_entry.delete(0, tk.END)
        chat_box.config(state=tk.DISABLED)

window = tk.Tk()
window.title("Chat with GPT")
window.geometry("500x600")
window.configure(bg="#2b2b2b")

chat_box = scrolledtext.ScrolledText(window, wrap=tk.WORD, width=40, height=20, bg="#333333", fg="white", font=("Arial", 17))
chat_box.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
chat_box.config(state=tk.DISABLED)

user_entry = tk.Entry(window, width=40, font=("Arial", 12), fg="white", bg="#444444", bd=2, relief="solid", insertbackground="white")
user_entry.grid(row=1, column=0, padx=10, pady=10, sticky="nsew")

send_button = tk.Button(window, text="Send", width=15, height=2, font=("Arial", 15, "bold"), bg="#4CAF50", fg="white", relief="flat", command=on_send)
send_button.grid(row=2, column=0, padx=10, pady=10)

window.grid_rowconfigure(0, weight=1)
window.grid_rowconfigure(1, weight=0)
window.grid_rowconfigure(2, weight=0)
window.grid_columnconfigure(0, weight=1)

chat_box.tag_configure('user', foreground='lightblue')
chat_box.tag_configure('chatbot', foreground='lightgreen')

window.mainloop()
